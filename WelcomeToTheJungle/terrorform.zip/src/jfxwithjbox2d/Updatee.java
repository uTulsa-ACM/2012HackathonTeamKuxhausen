package jfxwithjbox2d;

public interface Updatee {
	public void update(float timePassed);
}
